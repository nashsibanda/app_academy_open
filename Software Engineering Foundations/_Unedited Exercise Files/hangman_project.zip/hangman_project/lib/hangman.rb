class Hangman
  DICTIONARY = ["cat", "dog", "bootcamp", "pizza"]

end
